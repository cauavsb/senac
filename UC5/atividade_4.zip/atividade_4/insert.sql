INSERT INTO pre_agendamento (nome, telefone, data_consulta, animal, necessidade)
VALUES ('Cauã Vinícius', '(99)9.9999-9999', '2023-05-08', 'Coelho', 'Reabilitação');

INSERT INTO pre_agendamento (nome, telefone, data_consulta, animal, necessidade)
VALUES ('Marina Silva', '(88)9.8888-8888', '2023-05-10', 'Gato', 'Vacinação');

INSERT INTO pre_agendamento (nome, telefone, data_consulta, animal, necessidade)
VALUES ('João Otávio', '(77)9.7777-7777', '2023-05-12', 'Cachorro', 'Cirurgia');

INSERT INTO pre_agendamento (nome, telefone, data_consulta, animal, necessidade)
VALUES ('Ana Vitória', '(66)9.6666-6666', '2023-05-15', 'Hamster', 'Consulta de rotina');

INSERT INTO pre_agendamento (nome, telefone, data_consulta, animal, necessidade)
VALUES ('Lucas Silva', '(55)9.5555-5555', '2023-05-20', 'Cavalo', 'Consulta geral');