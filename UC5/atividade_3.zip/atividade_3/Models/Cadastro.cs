using System;
using System.Collections.Generic;

public class Cadastro
{
    public string nome { get; set; }
    public string telefone { get; set; }
    public string data { get; set; }
    public string animal { get; set; }
    public string necessidade { get; set; }
}